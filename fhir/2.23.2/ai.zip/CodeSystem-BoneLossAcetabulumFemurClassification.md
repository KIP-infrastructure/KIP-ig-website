# Bone loss - Acetabulum Femur Classification - KIP Infrastructure v2.23.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bone loss - Acetabulum Femur Classification**

## CodeSystem: Bone loss - Acetabulum Femur Classification 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/BoneLossAcetabulumFemurClassification | *Version*:2.23.2 |
| Active as of 2022-10-06 | *Computable Name*:BoneLossAcetabulumFemurClassification |

 
Walch classification; Link: https://radiopaedia.org/articles/walch-classification-of-glenoid-morphology-1 

 This Code system is referenced in the content logical definition of the following value sets: 

* [AcetabulumKnogletabKlassifikationDHR](ValueSet-AcetabulumKnogletabKlassifikationDHR.md)
* [FemurKnogletabKlassifikationDHR](ValueSet-FemurKnogletabKlassifikationDHR.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BoneLossAcetabulumFemurClassification",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/BoneLossAcetabulumFemurClassification",
  "version" : "2.23.2",
  "name" : "BoneLossAcetabulumFemurClassification",
  "title" : "Bone loss - Acetabulum Femur Classification",
  "status" : "active",
  "date" : "2022-10-06T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Walch classification; Link: https://radiopaedia.org/articles/walch-classification-of-glenoid-morphology-1",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 11,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "acetabulum_type_1",
    "display" : "Type I: Intet væsentligt knogletab",
    "definition" : "Type I: Intet væsentligt knogletab"
  },
  {
    "code" : "acetabulum_type_2",
    "display" : "Type II: Contained knogletab (intakt rim)",
    "definition" : "Type II: Contained knogletab (intakt rim)"
  },
  {
    "code" : "acetabulum_type_3",
    "display" : "Type III: Ikke contained segmentel knogletab",
    "definition" : "Type III: Ikke contained segmentel knogletab"
  },
  {
    "code" : "acetabulum_type_4",
    "display" : "Type IV: Ikke contained segmentelt knogletab involverende mere end 50% af acetabulum",
    "definition" : "Type IV: Ikke contained segmentelt knogletab involverende mere end 50% af acetabulum"
  },
  {
    "code" : "acetabulum_type_5",
    "display" : "Type V: Knogletab med discontinuitet af acetabulum",
    "definition" : "Type V: Knogletab med discontinuitet af acetabulum"
  },
  {
    "code" : "femur_type_1",
    "display" : "Type I: Intet væsentligt knogletab",
    "definition" : "Type I: Intet væsentligt knogletab"
  },
  {
    "code" : "femur_type_2",
    "display" : "Type II: Contained knogletab med cortikal udtynding",
    "definition" : "Type II: Contained knogletab med cortikal udtynding"
  },
  {
    "code" : "femur_type_3",
    "display" : "Type III: Ikke contained knogletab involverende calcar og trochanter minor med perforation af cortex",
    "definition" : "Type III: Ikke contained knogletab involverende calcar og trochanter minor med perforation af cortex"
  },
  {
    "code" : "femur_type_4",
    "display" : "Type IV: Ikke contained knogletab gående ned i diafysen",
    "definition" : "Type IV: Ikke contained knogletab gående ned i diafysen"
  },
  {
    "code" : "femur_type_5",
    "display" : "Type V: Fraktur omkring femurstemmet med circumferentielt knogletab svarende til type IV",
    "definition" : "Type V: Fraktur omkring femurstemmet med circumferentielt knogletab svarende til type IV"
  },
  {
    "code" : "femur_type_6",
    "display" : "Type VI: Fraktur omkring femurstemmet med knogletab svarende til type I-III",
    "definition" : "Type VI: Fraktur omkring femurstemmet med knogletab svarende til type I-III"
  }]
}

```
