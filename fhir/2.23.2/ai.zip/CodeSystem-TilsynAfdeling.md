# TilsynAfdeling - DPD - KIP Infrastructure v2.23.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **TilsynAfdeling - DPD**

## CodeSystem: TilsynAfdeling - DPD 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/TilsynAfdeling | *Version*:2.23.2 |
| Active as of 2026-06-24 | *Computable Name*:TilsynAfdelingCS |

 
TilsynAfdeling - DPD 

 This Code system is referenced in the content logical definition of the following value sets: 

* [TilsynAfdelingVS](ValueSet-TilsynAfdeling.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "TilsynAfdeling",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/TilsynAfdeling",
  "version" : "2.23.2",
  "name" : "TilsynAfdelingCS",
  "title" : "TilsynAfdeling - DPD",
  "status" : "active",
  "date" : "2026-06-24T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "TilsynAfdeling - DPD",
  "content" : "complete",
  "count" : 2,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "TilSyn",
    "display" : "Patienten blev set på et tilsyn på anden afdeling uden at patienten er blevet tilknyttet det palliative team",
    "definition" : "Patienten blev set på et tilsyn på anden afdeling uden at patienten er blevet tilknyttet det palliative team",
    "property" : [{
      "code" : "comment",
      "valueString" : "Added"
    },
    {
      "code" : "effectiveDate",
      "valueDateTime" : "2026-06-24T00:00:00+02:00"
    },
    {
      "code" : "status",
      "valueCode" : "active"
    },
    {
      "code" : "inactive",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "AldrigSet",
    "display" : "Patienten blev aldrig set",
    "definition" : "Patienten blev aldrig set",
    "property" : [{
      "code" : "comment",
      "valueString" : "Added"
    },
    {
      "code" : "effectiveDate",
      "valueDateTime" : "2026-06-24T00:00:00+02:00"
    },
    {
      "code" : "status",
      "valueCode" : "active"
    },
    {
      "code" : "inactive",
      "valueBoolean" : false
    }]
  }]
}

```
