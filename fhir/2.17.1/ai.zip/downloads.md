# Downloads - KIP Infrastructure v2.17.1

* [**Table of Contents**](toc.md)
* **Downloads**

## Downloads

### Downloads

Download the Implementation Guide and other content.

#### Full IG Download

* [Full IG](package.tgz)
* [History](/history.md)

#### Definitions

* [Definitions JSON](definitions.json.zip)
* [Definitions TTL](definitions.ttl.zip)
* [Definitions XML](definitions.xml.zip)

#### Examples

* [Examples JSON](examples.json.zip)
* [Examples TTL](examples.ttl.zip)
* [Examples XML](examples.xml.zip)

#### Expansions

* [Expansions JSON](expansions.json.zip)
* [Expansions XML](expansions.xml.zip)

