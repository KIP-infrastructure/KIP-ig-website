# ATC - Tromboseprofylakse (DKR) - KIP Infrastructure v2.19.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ATC - Tromboseprofylakse (DKR)**

## ValueSet: ATC - Tromboseprofylakse (DKR) (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/ATCTromboseprofylakseDKR | *Version*:2.19.1 |
| Active as of 2022-10-14 | *Computable Name*:ATCTromboseprofylakseDKR |

 
ATC - Tromboseprofylakse (DKR) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ATCTromboseprofylakseDKR",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/ATCTromboseprofylakseDKR",
  "version" : "2.19.1",
  "name" : "ATCTromboseprofylakseDKR",
  "title" : "ATC - Tromboseprofylakse (DKR)",
  "status" : "active",
  "experimental" : true,
  "date" : "2022-10-14T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "ATC - Tromboseprofylakse (DKR)",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/ATC",
      "concept" : [{
        "code" : "B01AF01",
        "display" : "Rivaroxaban (Xarelto)"
      },
      {
        "code" : "B01AB04",
        "display" : "Dalteparin (Fragmin)"
      },
      {
        "code" : "B01AB05",
        "display" : "Enoxaparin (Klexane)"
      },
      {
        "code" : "B01AE07",
        "display" : "Dabigatranetexilat (Pradaxa)"
      },
      {
        "code" : "B01AF02",
        "display" : "Apixaban (Eliquis)"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/GenericValues",
      "concept" : [{
        "code" : "other",
        "display" : "Andet"
      }]
    }]
  }
}

```
