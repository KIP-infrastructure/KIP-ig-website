# The National Institute of Health Stroke Scale (NIHSS) - 9. Best Language - KIP Infrastructure v1.25.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **The National Institute of Health Stroke Scale (NIHSS) - 9. Best Language**

## CodeSystem: The National Institute of Health Stroke Scale (NIHSS) - 9. Best Language 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/NIHSS9Language | *Version*:1.25.1 |
| Active as of 2022-06-23 | *Computable Name*:NIHSS9Language |

 
The National Institute of Health Stroke Scale (NIHSS) - 9. Best Language; Link: https://www.ninds.nih.gov/stroke-scales-and-related-information 

 This Code system is referenced in the content logical definition of the following value sets: 

* [NIHSS - 9. Sprog](ValueSet-NIHSS9Sprog.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "NIHSS9Language",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/NIHSS9Language",
  "version" : "1.25.1",
  "name" : "NIHSS9Language",
  "title" : "The National Institute of Health Stroke Scale (NIHSS) - 9. Best Language",
  "status" : "active",
  "date" : "2022-06-23T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "The National Institute of Health Stroke Scale (NIHSS) - 9. Best Language; Link: https://www.ninds.nih.gov/stroke-scales-and-related-information",
  "content" : "complete",
  "count" : 4,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "0",
    "display" : "0",
    "definition" : "No aphasia; normal."
  },
  {
    "code" : "1",
    "display" : "1",
    "definition" : "Mild-to-moderate aphasia; some obvious loss of fluency or facility of comprehension, without significant limitation on ideas expressed or form of expression. Reduction of speech and/or comprehension, however, makes conversation about provided materials difficult or impossible. For example, in conversation about provided materials, examiner can identify picture or naming card content from patient's response."
  },
  {
    "code" : "2",
    "display" : "2",
    "definition" : "Severe aphasia; all communication is through fragmentary expression; great need for inference, questioning, and guessing by the listener. Range of information that can be exchanged is limited; listener carries burden of communication. Examiner cannot identify materials provided from patient response."
  },
  {
    "code" : "3",
    "display" : "3",
    "definition" : "Mute, global aphasia; no usable speech or auditory comprehension."
  }]
}

```
