# Genoplivning - KIP Infrastructure v1.25.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Genoplivning**

## CodeSystem: Genoplivning 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/Genoplivning | *Version*:1.25.1 |
| Active as of 2022-06-29 | *Computable Name*:GenoplivningCS |

 
Aktivitet ifm genoplivning 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Genoplivning](ValueSet-Genoplivning.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "Genoplivning",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/Genoplivning",
  "version" : "1.25.1",
  "name" : "GenoplivningCS",
  "title" : "Genoplivning",
  "status" : "active",
  "date" : "2022-06-29T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Aktivitet ifm genoplivning",
  "content" : "complete",
  "count" : 4,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "hjertemass",
    "display" : "Hjertemassage",
    "definition" : "Hjertemassage alene"
  },
  {
    "code" : "ventilation",
    "display" : "Ventilation",
    "definition" : "Ventilation alene"
  },
  {
    "code" : "hjmass_vent",
    "display" : "Hjertemassage og ventilation",
    "definition" : "Hjertemassage og ventilation"
  },
  {
    "code" : "ingen",
    "display" : "Ingen",
    "definition" : "Ingen"
  }]
}

```
