# EHS ventral hernie type - KIP Infrastructure v1.25.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **EHS ventral hernie type**

## ValueSet: EHS ventral hernie type 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/EHSVentralHernieType | *Version*:1.25.1 |
| Active as of 2023-07-06 | *Computable Name*:EHSVentralHernieType |

 
EHS ventral hernie type - lateral højre/venstre og midtlinje 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "EHSVentralHernieType",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/EHSVentralHernieType",
  "version" : "1.25.1",
  "name" : "EHSVentralHernieType",
  "title" : "EHS ventral hernie type",
  "status" : "active",
  "date" : "2023-07-06T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "EHS ventral hernie type - lateral højre/venstre og midtlinje",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/EHSIncisionalHerniaClassificationType",
      "concept" : [{
        "code" : "ehslr",
        "display" : "EHS-klassifikation lateral - Højre"
      },
      {
        "code" : "ehsm",
        "display" : "EHS-klassifikation - Midtlinje"
      },
      {
        "code" : "ehsll",
        "display" : "EHS-klassifikation lateral - Venstre"
      }]
    }]
  }
}

```
