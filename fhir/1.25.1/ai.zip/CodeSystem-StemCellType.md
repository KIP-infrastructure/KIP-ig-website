# Stem cell type - KIP Infrastructure v1.25.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Stem cell type**

## CodeSystem: Stem cell type 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/StemCellType | *Version*:1.25.1 |
| Active as of 2022-06-07 | *Computable Name*:StemCellType |

 
Stem cell type 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Stamcelle type](ValueSet-CytogeneticStemCellType.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "StemCellType",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/StemCellType",
  "version" : "1.25.1",
  "name" : "StemCellType",
  "title" : "Stem cell type",
  "status" : "active",
  "date" : "2022-06-07T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Stem cell type",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 2,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "bone_marrow",
    "display" : "Bone marrow stromal stem cell",
    "definition" : "Bone marrow stromal stem cell / SNOMED-CT: 418460001"
  },
  {
    "code" : "peripheral_blood",
    "display" : "Peripheral blood stem cell",
    "definition" : "Peripheral blood stem cell / SNOMED-CT: 419583006"
  }]
}

```
