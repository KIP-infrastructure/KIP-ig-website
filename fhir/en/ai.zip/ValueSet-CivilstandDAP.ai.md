# Civilstand [DAP] - KIP Infrastructure v2.27.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Civilstand [DAP]**

## ValueSet: Civilstand [DAP] 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/CivilstandDAP | *Version*:2.27.0 |
| Active as of 2022-06-21 | *Computable Name*:CivilstandDAP |

 
Civilstand for Apopleksi [DAP] 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CivilstandDAP",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/CivilstandDAP",
  "version" : "2.27.0",
  "name" : "CivilstandDAP",
  "title" : "Civilstand [DAP]",
  "status" : "active",
  "date" : "2022-06-21T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Civilstand for Apopleksi [DAP]",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/MaritalStatus",
      "concept" : [{
        "code" : "cohabitant",
        "display" : "Samboende"
      },
      {
        "code" : "livingalone",
        "display" : "Bor alene"
      },
      {
        "code" : "other",
        "display" : "Andet"
      }]
    }]
  }
}

```
