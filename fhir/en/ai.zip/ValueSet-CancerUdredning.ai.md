# Cancer udredning - KIP Infrastructure v2.27.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cancer udredning**

## ValueSet: Cancer udredning 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/CancerUdredning | *Version*:2.27.3 |
| Active as of 2022-06-08 | *Computable Name*:CancerUdredning |

 
Valgmulighederne for cancer udredning 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CancerUdredning",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/CancerUdredning",
  "version" : "2.27.3",
  "name" : "CancerUdredning",
  "title" : "Cancer udredning",
  "status" : "active",
  "date" : "2022-06-08T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Valgmulighederne for cancer udredning",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/CancerInvestigation",
      "concept" : [{
        "code" : "eus",
        "display" : "EUS"
      },
      {
        "code" : "lap/lus",
        "display" : "Lap/LUS"
      },
      {
        "code" : "ct",
        "display" : "CT"
      },
      {
        "code" : "pet/ct",
        "display" : "PET/CT"
      },
      {
        "code" : "mr",
        "display" : "MR"
      },
      {
        "code" : "abdomen",
        "display" : "UL abdomen"
      },
      {
        "code" : "neck",
        "display" : "UL hals"
      },
      {
        "code" : "ebus",
        "display" : "EBUS"
      },
      {
        "code" : "other",
        "display" : "Øvrige"
      }]
    }]
  }
}

```
