# DVT profylakse, dosis (DKRR) - KIP Infrastructure v2.27.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **DVT profylakse, dosis (DKRR)**

## ValueSet: DVT profylakse, dosis (DKRR) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/DVTProfylakseDosisDKRR | *Version*:2.27.3 |
| Active as of 2022-09-19 | *Computable Name*:DVTProfylakseDosisDKRR |

 
DVT profylakse, dosis (DKRR) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "DVTProfylakseDosisDKRR",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/DVTProfylakseDosisDKRR",
  "version" : "2.27.3",
  "name" : "DVTProfylakseDosisDKRR",
  "title" : "DVT profylakse, dosis (DKRR)",
  "status" : "active",
  "date" : "2022-09-19T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "DVT profylakse, dosis (DKRR)",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/GenericValues",
      "concept" : [{
        "code" : "single_dose",
        "display" : "Engangsdosis"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/Intervals",
      "concept" : [{
        "code" : "<8",
        "display" : "<8 dage"
      },
      {
        "code" : "=>8",
        "display" : "=>8 dage"
      }]
    }]
  }
}

```
