# Referred from - KIP Infrastructure v2.27.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Referred from**

## CodeSystem: Referred from 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/ReferredFrom | *Version*:2.27.3 |
| Active as of 2022-08-23 | *Computable Name*:ReferredFrom |

 
Referred from 

This Code system is referenced in the definition of the following value sets:

* [Henvist fra](ValueSet-HenvistFra.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ReferredFrom",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/ReferredFrom",
  "version" : "2.27.3",
  "name" : "ReferredFrom",
  "title" : "Referred from",
  "status" : "active",
  "date" : "2022-08-23T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Referred from",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 5,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "own_doctor",
    "display" : "Own doctor",
    "definition" : "Own doctor / Egen læge"
  },
  {
    "code" : "specialist_doctor",
    "display" : "Specialist doctor",
    "definition" : "Specialist doctor / Speciallæge"
  },
  {
    "code" : "hospital_department",
    "display" : "Hospital department",
    "definition" : "Hospital department / Sygehusafdeling"
  },
  {
    "code" : "palliative_department",
    "display" : "Palliative department",
    "definition" : "Palliative department / Palliativ enhed"
  },
  {
    "code" : "patient_relavtives",
    "display" : "Patient or relatives",
    "definition" : "Patient or relatives / Patienten selv eller pårørende"
  }]
}

```
