# Aneurysm size scale (SAH) - KIP Infrastructure v2.27.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Aneurysm size scale (SAH)**

## CodeSystem: Aneurysm size scale (SAH) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/AneurysmSizeScale | *Version*:2.27.2 |
| Active as of 2022-06-14 | *Computable Name*:AneurysmSizeScale |

 
Aneurysm size scale (SAH) 

This Code system is referenced in the definition of the following value sets:

* [Anurisme stoerrelse [SAH]](ValueSet-AnurismeStoerrelseSAH.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "AneurysmSizeScale",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/AneurysmSizeScale",
  "version" : "2.27.2",
  "name" : "AneurysmSizeScale",
  "title" : "Aneurysm size scale (SAH)",
  "status" : "active",
  "date" : "2022-06-14T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Aneurysm size scale (SAH)",
  "content" : "fragment",
  "count" : 4,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "gt25",
    "display" : ">25 mm",
    "definition" : ">25 mm"
  },
  {
    "code" : "ge12le25",
    "display" : ">=12 mm, =<25 mm",
    "definition" : ">=12 mm, =<25 mm"
  },
  {
    "code" : "ge7lt12",
    "display" : ">=7 mm, <12 mm",
    "definition" : ">=7 mm, <12 mm"
  },
  {
    "code" : "lt7",
    "display" : "<7 mm",
    "definition" : "<7 mm"
  }]
}

```
