# Måleenheder - KIP Infrastructure v2.27.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Måleenheder**

## CodeSystem: Måleenheder 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/MaaleEnheder | *Version*:2.27.2 |
| Active as of 2022-08-01 | *Computable Name*:MaaleEnheder |

 
Enheder til dokumentation af mængde, vægt, længde mm. 

This Code system is referenced in the definition of the following value sets:

* [Alle Måleenheder](ValueSet-AlleMaaleEnheder.md)
* [Måleenhed HÆMA-2](ValueSet-MaaleEnhedHAEMA2.md)
* [Måleenhed HÆMA-3](ValueSet-MaaleEnhedHAEMA3.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "MaaleEnheder",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/MaaleEnheder",
  "version" : "2.27.2",
  "name" : "MaaleEnheder",
  "title" : "Måleenheder",
  "status" : "active",
  "date" : "2022-08-01T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Enheder til dokumentation af mængde, vægt, længde mm.",
  "content" : "complete",
  "count" : 29,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "procent",
    "display" : "%",
    "definition" : "Procent"
  },
  {
    "code" : "nm",
    "display" : "nm",
    "definition" : "Nanometer"
  },
  {
    "code" : "μm",
    "display" : "μm",
    "definition" : "Micrometer"
  },
  {
    "code" : "mm",
    "display" : "mm",
    "definition" : "Millimeter"
  },
  {
    "code" : "cm",
    "display" : "cm",
    "definition" : "Centimeter"
  },
  {
    "code" : "mg",
    "display" : "mg",
    "definition" : "Milligram"
  },
  {
    "code" : "g",
    "display" : "g",
    "definition" : "Gram"
  },
  {
    "code" : "kg",
    "display" : "kg",
    "definition" : "Kilogram"
  },
  {
    "code" : "mol-l",
    "display" : "mol-l",
    "definition" : "Molær koncentration per liter"
  },
  {
    "code" : "mmol-l",
    "display" : "mmol/L",
    "definition" : "Millimol per liter"
  },
  {
    "code" : "μmol-l",
    "display" : "μmol/L",
    "definition" : "Mikromol per liter"
  },
  {
    "code" : "nmol-l",
    "display" : "nmol/L",
    "definition" : "Nanomol per liter"
  },
  {
    "code" : "u-l",
    "display" : "U/L",
    "definition" : "Enhed U per liter"
  },
  {
    "code" : "kiu-l",
    "display" : "kiU/L",
    "definition" : "Kilo antistof enhed per liter"
  },
  {
    "code" : "mia-L",
    "display" : "mia/L",
    "definition" : "Antal milliarder per liter"
  },
  {
    "code" : "fl",
    "display" : "fl",
    "definition" : "10^-15 L"
  },
  {
    "code" : "g-l",
    "display" : "g/L",
    "definition" : "Gram per liter"
  },
  {
    "code" : "arb-enh",
    "display" : "arb.enh",
    "definition" : "Arbejdsenheder"
  },
  {
    "code" : "g-24h",
    "display" : "g/24h",
    "definition" : "Gram per døgn"
  },
  {
    "code" : "mg-l",
    "display" : "mg/L",
    "definition" : "Milligram per liter"
  },
  {
    "code" : "microglobulin-l",
    "display" : "microglobulin/L",
    "definition" : "Microglobulin per liter"
  },
  {
    "code" : "volfr",
    "display" : "vol.fr",
    "definition" : "volumenfraktion"
  },
  {
    "code" : "μg-l",
    "display" : "μg/L",
    "definition" : "Mikrogram per liter"
  },
  {
    "code" : "mCi-kg",
    "display" : "mCi/kg",
    "definition" : "milliCurie/kg"
  },
  {
    "code" : "gy",
    "display" : "Gy",
    "definition" : "Gray"
  },
  {
    "code" : "liter",
    "display" : "l",
    "definition" : "Liter"
  },
  {
    "code" : "deciliter",
    "display" : "dl",
    "definition" : "Deciliter"
  },
  {
    "code" : "centiliter",
    "display" : "cl",
    "definition" : "Centiliter"
  },
  {
    "code" : "milliliter",
    "display" : "ml",
    "definition" : "Milliliter"
  }]
}

```
