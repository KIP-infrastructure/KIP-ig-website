# Chromosom pair - KIP Infrastructure v2.27.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Chromosom pair**

## CodeSystem: Chromosom pair 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/ChromosomPair | *Version*:2.27.3 |
| Active as of 2022-07-13 | *Computable Name*:ChromosomPair |

 
Chromosom pair 

This Code system is referenced in the definition of the following value sets:

* [Kromosom par](ValueSet-ChromosomPairs.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ChromosomPair",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/ChromosomPair",
  "version" : "2.27.3",
  "name" : "ChromosomPair",
  "title" : "Chromosom pair",
  "status" : "active",
  "date" : "2022-07-13T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Chromosom pair",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 2,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "pair_13",
    "display" : "Chromosom pair 13",
    "definition" : "Chromosom pair 13 / Kromosompar 13 / SNOMED-CT: 55401003"
  },
  {
    "code" : "pair_17",
    "display" : "Chromosom pair 17",
    "definition" : "Chromosom pair 17 / Kromosompar 17 / SNOMED-CT: 45201007"
  }]
}

```
