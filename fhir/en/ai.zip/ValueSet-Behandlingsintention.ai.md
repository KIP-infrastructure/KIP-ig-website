# Behandlingsintention - KIP Infrastructure v2.27.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Behandlingsintention**

## ValueSet: Behandlingsintention 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/Behandlingsintention | *Version*:2.27.3 |
| Active as of 2022-05-16 | *Computable Name*:Behandlingsintention |

 
Behandlingsintention 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "Behandlingsintention",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/Behandlingsintention",
  "version" : "2.27.3",
  "name" : "Behandlingsintention",
  "title" : "Behandlingsintention",
  "status" : "active",
  "date" : "2022-05-16T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Behandlingsintention",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/TreatmentIntention",
      "concept" : [{
        "code" : "surgical/endoscopic",
        "display" : "Kurativt intenderet, kirurgi/endoskopi"
      },
      {
        "code" : "oncological",
        "display" : "Kurativt intenderet, definitiv onkologisk"
      },
      {
        "code" : "palliative",
        "display" : "Primær palliativt intenderet"
      }]
    }]
  }
}

```
