# Procedure duration: Codes for different durations - KIP Infrastructure v2.27.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Procedure duration: Codes for different durations**

## CodeSystem: Procedure duration: Codes for different durations 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/ProcedureDuration | *Version*:2.27.3 |
| Active as of 2022-06-29 | *Computable Name*:ProcedureDuration |

 
Procedure duration: Codes for different durations 

This Code system is referenced in the definition of the following value sets:

* [Behandlingsvarighed](ValueSet-BehandlingsVarighedDHR.md)
* [Procedure varighed; over/under 15 min.](ValueSet-ProcedureVarighed15min.md)
* [Procedure varighed; over/under 5 min.](ValueSet-ProcedureVarighed5min.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ProcedureDuration",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/ProcedureDuration",
  "version" : "2.27.3",
  "name" : "ProcedureDuration",
  "title" : "Procedure duration: Codes for different durations",
  "status" : "active",
  "date" : "2022-06-29T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Procedure duration: Codes for different durations",
  "content" : "complete",
  "count" : 8,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "=<1",
    "display" : "=<1",
    "definition" : "=<1"
  },
  {
    "code" : ">1",
    "display" : ">1",
    "definition" : ">1"
  },
  {
    "code" : "=<2",
    "display" : "=<2",
    "definition" : "=<2"
  },
  {
    "code" : ">2",
    "display" : ">2",
    "definition" : ">2"
  },
  {
    "code" : "=<5",
    "display" : "=<5",
    "definition" : "=<5"
  },
  {
    "code" : ">5",
    "display" : ">5",
    "definition" : ">5"
  },
  {
    "code" : "=<15",
    "display" : "=<15",
    "definition" : "=<15"
  },
  {
    "code" : ">15",
    "display" : ">15",
    "definition" : ">15"
  }]
}

```
