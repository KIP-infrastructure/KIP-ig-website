# The National Institute of Health Stroke Scale (NIHSS) - 7. Limb Ataxia - KIP Infrastructure v2.27.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **The National Institute of Health Stroke Scale (NIHSS) - 7. Limb Ataxia**

## CodeSystem: The National Institute of Health Stroke Scale (NIHSS) - 7. Limb Ataxia 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/NIHSS7LimbAtaxia | *Version*:2.27.3 |
| Active as of 2022-06-23 | *Computable Name*:NIHSS7LimbAtaxia |

 
The National Institute of Health Stroke Scale (NIHSS) - 7. Limb Ataxia; Link: https://www.ninds.nih.gov/stroke-scales-and-related-information 

This Code system is referenced in the definition of the following value sets:

* [NIHSS - 7. Ekstremitets ataksi](ValueSet-NIHSS7Ataksi.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "NIHSS7LimbAtaxia",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/NIHSS7LimbAtaxia",
  "version" : "2.27.3",
  "name" : "NIHSS7LimbAtaxia",
  "title" : "The National Institute of Health Stroke Scale (NIHSS) - 7. Limb Ataxia",
  "status" : "active",
  "date" : "2022-06-23T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "The National Institute of Health Stroke Scale (NIHSS) - 7. Limb Ataxia; Link: https://www.ninds.nih.gov/stroke-scales-and-related-information",
  "content" : "complete",
  "count" : 4,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "0",
    "display" : "0",
    "definition" : "Absent."
  },
  {
    "code" : "1",
    "display" : "1",
    "definition" : "Present in one limb."
  },
  {
    "code" : "2",
    "display" : "2",
    "definition" : "Present in two limbs."
  },
  {
    "code" : "UN",
    "display" : "UN",
    "definition" : "Amputation or joint fusion, explain:"
  }]
}

```
