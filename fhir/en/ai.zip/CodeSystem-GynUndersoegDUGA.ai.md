# Gynækologisk undersøgelsesmetode (DUGA) - KIP Infrastructure v2.27.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Gynækologisk undersøgelsesmetode (DUGA)**

## CodeSystem: Gynækologisk undersøgelsesmetode (DUGA) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/GynUndersoegDUGA | *Version*:2.27.0 |
| Active as of 2024-02-13 | *Computable Name*:GynUndersoegDUGACS |

 
Gynækologisk undersøgelsesmetode (DUGA) 

This Code system is referenced in the definition of the following value sets:

* [Gynækologisk undersøgelsesmetode (DUGA)](ValueSet-GynUndersoegDUGA.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "GynUndersoegDUGA",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/GynUndersoegDUGA",
  "version" : "2.27.0",
  "name" : "GynUndersoegDUGACS",
  "title" : "Gynækologisk undersøgelsesmetode (DUGA)",
  "status" : "active",
  "date" : "2024-02-13T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Gynækologisk undersøgelsesmetode (DUGA)",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 2,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "popq",
    "display" : "POPQ",
    "definition" : "POPQ"
  },
  {
    "code" : "hymscore",
    "display" : "Score i forhold til hymenal plan",
    "definition" : "Score i forhold til hymenal plan"
  }]
}

```
