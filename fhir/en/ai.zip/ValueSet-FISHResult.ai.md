# Resultat af FISH - KIP Infrastructure v2.27.3

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Resultat af FISH**

## ValueSet: Resultat af FISH 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/FISHResult | *Version*:2.27.3 |
| Active as of 2022-07-15 | *Computable Name*:FISHResult |

 
Resultat af FISH 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "FISHResult",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/FISHResult",
  "version" : "2.27.3",
  "name" : "FISHResult",
  "title" : "Resultat af FISH",
  "status" : "active",
  "date" : "2022-07-15T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Resultat af FISH",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/FISHVariables",
      "concept" : [{
        "code" : "igh_fgfr3",
        "display" : "t(4;14)/IGH-FGFR3"
      },
      {
        "code" : "igh_ccnd1",
        "display" : "t(11;14)/IGH-CCND1"
      },
      {
        "code" : "igh_mbf",
        "display" : "t(14;16)/IGH-MBF"
      },
      {
        "code" : "igh_mafb",
        "display" : "t(14;20)/IGH-MAFB"
      },
      {
        "code" : "igh_split_signal",
        "display" : "IgH split signal"
      },
      {
        "code" : "13q_deletion",
        "display" : "13q deletion"
      },
      {
        "code" : "tp53_deletion",
        "display" : "TP53 deletion"
      },
      {
        "code" : "1q21",
        "display" : "1q21 amplifikation"
      },
      {
        "code" : "11q22",
        "display" : "11q22/ATM amplifikation"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/GenericValues",
      "concept" : [{
        "code" : "other",
        "display" : "Anden IGH translokation"
      },
      {
        "code" : "none",
        "display" : "Ingen forandringer påvist"
      }]
    }]
  }
}

```
