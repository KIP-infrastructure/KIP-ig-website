# Harris Hip Score (HHS) - Distance walked - KIP Infrastructure v2.27.2

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Harris Hip Score (HHS) - Distance walked**

## CodeSystem: Harris Hip Score (HHS) - Distance walked 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/HarrisHipScoreDistanceWalked | *Version*:2.27.2 |
| Active as of 2022-07-06 | *Computable Name*:HarrisHipScoreDistanceWalked |

 
Harris Hip Score (HHS) - Distance walked. Link: https://www.orthopaedicscore.com/scorepages/harris_hip_score.html 

This Code system is referenced in the definition of the following value sets:

* [Harris Hip Score - Gangdistance](ValueSet-HarrisHipScoreGangdistance.md)

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "HarrisHipScoreDistanceWalked",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/HarrisHipScoreDistanceWalked",
  "version" : "2.27.2",
  "name" : "HarrisHipScoreDistanceWalked",
  "title" : "Harris Hip Score (HHS) - Distance walked",
  "status" : "active",
  "date" : "2022-07-06T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Harris Hip Score (HHS) - Distance walked. Link: https://www.orthopaedicscore.com/scorepages/harris_hip_score.html",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 5,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "11",
    "display" : "Unlimited",
    "definition" : "Unlimited (11)"
  },
  {
    "code" : "8",
    "display" : "Six blocks (30 minutes)",
    "definition" : "Six blocks (30 minutes) (8)"
  },
  {
    "code" : "5",
    "display" : "Two og three blocks (10-15 minutes)",
    "definition" : "Two og three blocks (10-15 minutes) (5)"
  },
  {
    "code" : "2",
    "display" : "Indoors only",
    "definition" : "Indoors only (2)"
  },
  {
    "code" : "0",
    "display" : "Bed and chair only",
    "definition" : "Bed and chair only (0)"
  }]
}

```
