# Grafts for cruciate ligaments; types of grafts - KIP Infrastructure v2.23.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Grafts for cruciate ligaments; types of grafts**

## CodeSystem: Grafts for cruciate ligaments; types of grafts 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/GraftCruciateLigaments | *Version*:2.23.1 |
| Active as of 2022-09-19 | *Computable Name*:GraftCruciateLigaments |

 
Grafts for cruciate ligaments, types of grafts 

 This Code system is referenced in the content logical definition of the following value sets: 

* [GraftACLDKRR](ValueSet-GraftACLDKRR.md)
* [GraftDKRR](ValueSet-GraftDKRR.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "GraftCruciateLigaments",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/GraftCruciateLigaments",
  "version" : "2.23.1",
  "name" : "GraftCruciateLigaments",
  "title" : "Grafts for cruciate ligaments; types of grafts",
  "status" : "active",
  "date" : "2022-09-19T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Grafts for cruciate ligaments, types of grafts",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 16,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "acl_repair_synthetic_reinforced",
    "display" : "ACL repair med syntetisk forstærkning",
    "definition" : "ACL repair med syntetisk forstærkning"
  },
  {
    "code" : "bach-allo",
    "display" : "BACH-Allo",
    "definition" : "BACH-Allo"
  },
  {
    "code" : "bptb",
    "display" : "BPTB",
    "definition" : "BPTB"
  },
  {
    "code" : "bptb-allo",
    "display" : "BPTB-Allo",
    "definition" : "BPTB-Allo"
  },
  {
    "code" : "bqt",
    "display" : "BQT",
    "definition" : "BQT"
  },
  {
    "code" : "bqt-allo",
    "display" : "BQT-Allo",
    "definition" : "BQT-Allo"
  },
  {
    "code" : "direct_suture",
    "display" : "Direkte sutur",
    "definition" : "Direkte sutur"
  },
  {
    "code" : "double-bundle_bqt",
    "display" : "Double-bundle BQT",
    "definition" : "Double-bundle BQT"
  },
  {
    "code" : "double-bundle_st",
    "display" : "Double-bundle ST",
    "definition" : "Double-bundle ST"
  },
  {
    "code" : "qt_without_bone_block",
    "display" : "QT uden knogleklods",
    "definition" : "QT uden knogleklods"
  },
  {
    "code" : "st_double",
    "display" : "ST - Double",
    "definition" : "ST - Double"
  },
  {
    "code" : "st_quadro",
    "display" : "ST - Quadro",
    "definition" : "ST - Quadro"
  },
  {
    "code" : "st_triple",
    "display" : "ST - Triple",
    "definition" : "ST - Triple"
  },
  {
    "code" : "st/gr",
    "display" : "ST/GR",
    "definition" : "ST/GR"
  },
  {
    "code" : "st/gr_allo",
    "display" : "ST/GR allo",
    "definition" : "ST/GR allo"
  },
  {
    "code" : "synthetic",
    "display" : "Syntetisk graft",
    "definition" : "Syntetisk graft"
  }]
}

```
