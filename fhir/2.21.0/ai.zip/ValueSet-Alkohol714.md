# Alkohol - 7/14 genstande per uge - KIP Infrastructure v2.21.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Alkohol - 7/14 genstande per uge**

## ValueSet: Alkohol - 7/14 genstande per uge (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/Alkohol714 | *Version*:2.21.0 |
| Active as of 2022-06-08 | *Computable Name*:Alkohol714 |

 
Udfald for alkohol - 7/14 genstande per uge 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "Alkohol714",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/Alkohol714",
  "version" : "2.21.0",
  "name" : "Alkohol714",
  "title" : "Alkohol - 7/14 genstande per uge",
  "status" : "active",
  "experimental" : true,
  "date" : "2022-06-08T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Udfald for alkohol - 7/14 genstande per uge",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/Alchohol",
      "concept" : [{
        "code" : "le7/14",
        "display" : "7/14 genstande eller færre (kvinde/mand)"
      },
      {
        "code" : "gt7/14",
        "display" : "Over 7/14 genstande per uge (kvinde/mand)"
      }]
    }]
  }
}

```
