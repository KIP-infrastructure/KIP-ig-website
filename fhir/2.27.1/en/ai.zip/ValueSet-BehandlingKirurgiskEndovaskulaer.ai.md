# Behandling; kirurgisk og endovaskulær - KIP Infrastructure v2.27.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Behandling; kirurgisk og endovaskulær**

## ValueSet: Behandling; kirurgisk og endovaskulær 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/BehandlingKirurgiskEndovaskulaer | *Version*:2.27.1 |
| Active as of 2022-06-28 | *Computable Name*:BehandlingKirurgiskEndovaskulaer |

 
Behandling; kirurgisk og endovaskulær 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BehandlingKirurgiskEndovaskulaer",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/BehandlingKirurgiskEndovaskulaer",
  "version" : "2.27.1",
  "name" : "BehandlingKirurgiskEndovaskulaer",
  "title" : "Behandling; kirurgisk og endovaskulær",
  "status" : "active",
  "date" : "2022-06-28T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Behandling; kirurgisk og endovaskulær",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/TreatmentType",
      "concept" : [{
        "code" : "endovascular",
        "display" : "Endovaskulær behandling"
      },
      {
        "code" : "surgical",
        "display" : "Kirurgisk behandling"
      }]
    }]
  }
}

```
