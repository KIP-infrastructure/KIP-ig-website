# Harris Hip Score - Gangdistance - KIP Infrastructure v2.27.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Harris Hip Score - Gangdistance**

## ValueSet: Harris Hip Score - Gangdistance 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/HarrisHipScoreGangdistance | *Version*:2.27.1 |
| Active as of 2022-11-15 | *Computable Name*:HarrisHipScoreGangdistance |

 
Harris Hip Score - Gangdistance 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 [Description of the above table(s)](http://build.fhir.org/ig/FHIR/ig-guidance/readingIgs.html#terminology). 



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "HarrisHipScoreGangdistance",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/HarrisHipScoreGangdistance",
  "version" : "2.27.1",
  "name" : "HarrisHipScoreGangdistance",
  "title" : "Harris Hip Score - Gangdistance",
  "status" : "active",
  "date" : "2022-11-15T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Harris Hip Score - Gangdistance",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/HarrisHipScoreDistanceWalked",
      "concept" : [{
        "code" : "11",
        "display" : "Ubegrænset"
      },
      {
        "code" : "8",
        "display" : "1,5-2 km"
      },
      {
        "code" : "5",
        "display" : "0,5-1 km"
      },
      {
        "code" : "2",
        "display" : "Kun indendørs"
      },
      {
        "code" : "0",
        "display" : "Bunden til seng/kørestol"
      }]
    }]
  }
}

```
