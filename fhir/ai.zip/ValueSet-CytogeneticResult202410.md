# Cytogenetic resultater 202410 - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cytogenetic resultater 202410**

## ValueSet: Cytogenetic resultater 202410 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/CytogeneticResult202410 | *Version*:2.26.1 |
| Active as of 2024-10-02 | *Computable Name*:CytogeneticResult202410 |

 
Cytogenetiske positive fund - DMPN. Valueset erstatter tidligere pr. Okt. 2024 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "CytogeneticResult202410",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/CytogeneticResult202410",
  "version" : "2.26.1",
  "name" : "CytogeneticResult202410",
  "title" : "Cytogenetic resultater 202410",
  "status" : "active",
  "date" : "2024-10-02T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Cytogenetiske positive fund - DMPN. Valueset erstatter tidligere pr. Okt. 2024",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/GenericValues",
      "concept" : [{
        "code" : "normal",
        "display" : "Normal undersøgelse"
      },
      {
        "code" : "abnormal",
        "display" : "Andre abnorme molekylærbiologiske fund"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/CytogeneticExamination",
      "concept" : [{
        "code" : "jak2_v617f",
        "display" : "JAK-2 muteret allebyrde (%)"
      },
      {
        "code" : "mpl",
        "display" : "MPL muteret allebyrde (%)"
      },
      {
        "code" : "jak2_exon12",
        "display" : "JAK2 Exon12"
      },
      {
        "code" : "cal-r",
        "display" : "CAL-R muteret allebyrde (%)"
      },
      {
        "code" : "asxl1",
        "display" : "ASXL1"
      }]
    }]
  }
}

```
