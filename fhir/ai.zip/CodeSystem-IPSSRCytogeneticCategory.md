# IPSS-R - Cytogenetic Category - KIP Infrastructure v2.23.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **IPSS-R - Cytogenetic Category**

## CodeSystem: IPSS-R - Cytogenetic Category 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/IPSSRCytogeneticCategory | *Version*:2.23.0 |
| Active as of 2022-06-07 | *Computable Name*:IPSSRCytogeneticCategory |

 
IPSS-R - Cytogenetic Category. Link: https://www.hematology.dk/index.php/vejledninger/udregnere/330-ipss-r 

 This Code system is referenced in the content logical definition of the following value sets: 

* [IPSSRCytogenetiskRisiko](ValueSet-IPSSRCytogenetiskRisiko.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "IPSSRCytogeneticCategory",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/IPSSRCytogeneticCategory",
  "version" : "2.23.0",
  "name" : "IPSSRCytogeneticCategory",
  "title" : "IPSS-R - Cytogenetic Category",
  "status" : "active",
  "date" : "2022-06-07T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "IPSS-R - Cytogenetic Category. Link: https://www.hematology.dk/index.php/vejledninger/udregnere/330-ipss-r",
  "caseSensitive" : true,
  "content" : "fragment",
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "0",
    "display" : "Very good: -Y, del(11q)",
    "definition" : "Very good: -Y, del(11q)"
  },
  {
    "code" : "1",
    "display" : "Good: normal, del(5q), del(12p), del(20q), double including del(5q)",
    "definition" : "Good: normal, del(5q), del(12p), del(20q), double including del(5q)"
  },
  {
    "code" : "2",
    "display" : "Intermediate: del(7q), +8, +19, i(17q), any other single or double independent clones",
    "definition" : "Intermediate: del(7q), +8, +19, i(17q), any other single or double independent clones"
  },
  {
    "code" : "3",
    "display" : "Poor: -7, inv(3)/t(3q)/del(3q), double including -7/del(7q), complex with 3 abnormalities",
    "definition" : "Poor: -7, inv(3)/t(3q)/del(3q), double including -7/del(7q), complex with 3 abnormalities"
  },
  {
    "code" : "4",
    "display" : "Very poor: complex with >3 abnomalities",
    "definition" : "Very poor: complex with >3 abnomalities"
  }]
}

```
