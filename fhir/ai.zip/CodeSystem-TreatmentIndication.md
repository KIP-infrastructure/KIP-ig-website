# Treatment indication - KIP Infrastructure v2.25.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Treatment indication**

## CodeSystem: Treatment indication 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/TreatmentIndication | *Version*:2.25.0 |
| Active as of 2022-07-12 | *Computable Name*:TreatmentIndication |

 
Treatment indication 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Indikation for TES](ValueSet-IndikationTES.md)
* [Treatment_Indication_CLL](ValueSet-TreatmentIndicationCLL.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "TreatmentIndication",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/TreatmentIndication",
  "version" : "2.25.0",
  "name" : "TreatmentIndication",
  "title" : "Treatment indication",
  "status" : "active",
  "date" : "2022-07-12T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Treatment indication",
  "content" : "complete",
  "count" : 5,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "cll",
    "display" : "CLL",
    "definition" : "CLL"
  },
  {
    "code" : "autoimmune",
    "display" : "Autoimmune fænomener",
    "definition" : "Autoimmune fænomener"
  },
  {
    "code" : "histological_verified",
    "display" : "Histologisk verificeret",
    "definition" : "Histologisk verificeret"
  },
  {
    "code" : "diagnostic",
    "display" : "Diagnostisk",
    "definition" : "Diagnostisk"
  },
  {
    "code" : "additional_procedure",
    "display" : "Supplerende procedure",
    "definition" : "Supplerende procedure"
  }]
}

```
