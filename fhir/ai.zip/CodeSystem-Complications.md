# Complications - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Complications**

## CodeSystem: Complications 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/Complications | *Version*:2.26.1 |
| Active as of 2022-06-07 | *Computable Name*:Complications |

 
Complications - several procedures 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Responsevaluering på behandling (LYFO)](ValueSet-BehandlingsResponsEvalueringLYFO.md)
* [Anæstesi komplikationer](ValueSet-ComplicationAN.md)
* [Anæstesi komplikationer 2026](ValueSet-ComplicationAN2026.md)
* [Postoperativ komplikatione](ValueSet-ComplicationPO.md)
* [Postoperativ komplikationer 2026](ValueSet-ComplicationPO2026.md)
* [Manifeste komplikationer](ValueSet-ComplicationsManifestation.md)
* [Manifeste komplikationer 202412](ValueSet-ComplicationsManifestation202412.md)
* [Dødsårsager [ALD]](ValueSet-DoedsaarsagALD.md)
* [Dødsårsager [DAMYDA]](ValueSet-DoedsaarsagDAMYDA.md)
* [Dødsårsager [SAH]](ValueSet-DoedsaarsagSAH.md)
* [Position af STEMI hjertestop](ValueSet-HeartAttackSTEMIPosition.md)
* [Hjertestop type](ValueSet-HeartAttackTypes.md)
* [Killip sværhedsgrad](ValueSet-HeartFailure.md)
* [Komplikationer, behandling (DEGC)](ValueSet-KomplikationerBehandlingDEGC.md)
* [Komplikationer (DKRR)](ValueSet-KomplikationerDKRR.md)
* [Komplikationer, endovaskulær [SAH]](ValueSet-KomplikationerEndovaskulaerSAH.md)
* [Komplikationer, kirurgisk [SAH]](ValueSet-KomplikationerKirurgiskSAH.md)
* [Komplikationer, peroperative (DKR)](ValueSet-KomplikationerPeroperativeDKR.md)
* [Komplikationer Vaskulær DMPN](ValueSet-KomplikationerVaskulaerDMPN.md)
* [Operationssår infektion (KAR)](ValueSet-OperationssaarInfektionKAR.md)
* [Operationssår komplikationer (KAR)](ValueSet-OperationssaarKomplikationerKAR.md)
* [Postoperative komplikationer (DCCG)](ValueSet-PostoperativeKomplikationerDCCG.md)
* [Patient respons på behandling (ALD)](ValueSet-TreatmentResponseALD.md)
* [Patient respons på behandling (DAMYDA)](ValueSet-TreatmentResponseDAMYDA.md)
* [Treatment_Response_Evaluation_CLL](ValueSet-TreatmentResponseEvaluationCLL.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "Complications",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/Complications",
  "version" : "2.26.1",
  "name" : "Complications",
  "title" : "Complications",
  "status" : "active",
  "date" : "2022-06-07T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Complications - several procedures",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 77,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "ami",
    "display" : "AMI",
    "definition" : "AMI - Myocardieinfarkt"
  },
  {
    "code" : "chylothorax",
    "display" : "Chylothorax",
    "definition" : "Chylothorax"
  },
  {
    "code" : "fascierupture",
    "display" : "Fascieruptur",
    "definition" : "Fascieruptur"
  },
  {
    "code" : "ileus",
    "display" : "Ileus",
    "definition" : "Ileus"
  },
  {
    "code" : "intrathoracicbleeding",
    "display" : "Intrathorakal blødning",
    "definition" : "Intrathorakal blødning"
  },
  {
    "code" : "intraabdominalabscess",
    "display" : "Intraabdominal absces",
    "definition" : "Intraabdominal absces"
  },
  {
    "code" : "intraabdominalbleeding",
    "display" : "Intraabdominal blødning",
    "definition" : "Intraabdominal blødning"
  },
  {
    "code" : "pulmonaryembolism",
    "display" : "Lungeemboli",
    "definition" : "Lungeemboli"
  },
  {
    "code" : "perforation",
    "display" : "Perforation",
    "definition" : "Perforation",
    "concept" : [{
      "code" : "bloodvessel/aneurysm",
      "display" : "Kar/anurisme",
      "definition" : "Perforation af kar eller aneurisme"
    }]
  },
  {
    "code" : "pleuraexudate",
    "display" : "Pleuraeksudat",
    "definition" : "Pleuraeksudat"
  },
  {
    "code" : "pneumonia",
    "display" : "Pneumoni",
    "definition" : "Pneumoni"
  },
  {
    "code" : "infection",
    "display" : "Sårinfektion",
    "definition" : "Sårinfektion"
  },
  {
    "code" : "anafylSchock",
    "display" : "Anafylaktisk reaktion/shock",
    "definition" : "Anafylaktisk reaktion/shock"
  },
  {
    "code" : "anInterrupt",
    "display" : "Anæstesi afbrudt",
    "definition" : "Anæstesi afbrudt"
  },
  {
    "code" : "appFailure",
    "display" : "Apparaturfejl",
    "definition" : "Apparaturfejl",
    "property" : [{
      "code" : "comment",
      "valueString" : "Removed"
    },
    {
      "code" : "effectiveDate",
      "valueDateTime" : "2026-03-04T00:00:00+01:00"
    },
    {
      "code" : "status",
      "valueCode" : "retired"
    },
    {
      "code" : "inactive",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "aspiration",
    "display" : "Aspiration",
    "definition" : "Aspiration"
  },
  {
    "code" : "duraptAcc",
    "display" : "Durapunktur accidentel",
    "definition" : "Durapunktur accidentel"
  },
  {
    "code" : "heartFail",
    "display" : "Hjertestop",
    "definition" : "Hjertestop"
  },
  {
    "code" : "huskeAN",
    "display" : "Huskeanæstesi",
    "definition" : "Huskeanæstesi"
  },
  {
    "code" : "malignHyp",
    "display" : "Malign Hypertermi mistanke",
    "definition" : "Malign Hypertermi mistanke"
  },
  {
    "code" : "medFail",
    "display" : "Medicineringsfejl",
    "definition" : "Medicineringsfejl",
    "property" : [{
      "code" : "comment",
      "valueString" : "Removed"
    },
    {
      "code" : "effectiveDate",
      "valueDateTime" : "2026-03-04T00:00:00+01:00"
    },
    {
      "code" : "status",
      "valueCode" : "retired"
    },
    {
      "code" : "inactive",
      "valueBoolean" : true
    }]
  },
  {
    "code" : "neuMuscBlock",
    "display" : "Neuromuskulær blokade, forlænget virkning",
    "definition" : "Neuromuskulær blokade, forlænget virkning"
  },
  {
    "code" : "dentInj",
    "display" : "Tandskade",
    "definition" : "Tandskade"
  },
  {
    "code" : "mors",
    "display" : "Mors, uventet",
    "definition" : "Mors, uventet"
  },
  {
    "code" : "dissection",
    "display" : "Dissektion",
    "definition" : "Dissektion"
  },
  {
    "code" : "thromboembolic",
    "display" : "Tromboemboliske komplikationer",
    "definition" : "Tromboemboliske komplikationer som medfører infarkt inden for 24 timer"
  },
  {
    "code" : "groinbleeding",
    "display" : "Blødning fra lysken",
    "definition" : "Alvorlig blødning fra lysken"
  },
  {
    "code" : "mechanical",
    "display" : "Mekaniske",
    "definition" : "Mekaniske komplikationer"
  },
  {
    "code" : "bloodvesselocclusion",
    "display" : "Aflukning af kar",
    "definition" : "Aflukning af kar medførende infarkt indenfor 24 timer"
  },
  {
    "code" : "peroperativebleeding",
    "display" : "Peroperativ blødning",
    "definition" : "Livstruende peroperativ blødning, der ikke kan kontrolleres inden for få sekunder"
  },
  {
    "code" : "other",
    "display" : "Other",
    "definition" : "Other"
  },
  {
    "code" : "vascular-unspecific",
    "display" : "Vascular, unspecific",
    "definition" : "Vascular, unspecific"
  },
  {
    "code" : "infarction-unspecific",
    "display" : "Cerebral infarction and bleeding, unspecific",
    "definition" : "Cerebral infarction and bleeding, unspecific"
  },
  {
    "code" : "post_polypectomy_syndrome",
    "display" : "Post polypectomy syndrome",
    "definition" : "Post polypectomy syndrome / Postpolypektomisyndrom"
  },
  {
    "code" : "urinary_retention",
    "display" : "Urinary retention",
    "definition" : "Urinary retention / Urinretention"
  },
  {
    "code" : "medical",
    "display" : "Medical complication",
    "definition" : "Medical complication / Medicinsk komplikation"
  },
  {
    "code" : "movement_restriction",
    "display" : "Movement restriction",
    "definition" : "Movement restriction / Bevægelsesindskrænkning"
  },
  {
    "code" : "chronic_pain",
    "display" : "Chronic pain",
    "definition" : "Chronic pain / Kronisk smerte"
  },
  {
    "code" : "reoperation",
    "display" : "Reoperation",
    "definition" : "Reoperation"
  },
  {
    "code" : "rupture",
    "display" : "Rupture",
    "definition" : "Rupture / Ruptur",
    "concept" : [{
      "code" : "rupture_patella_ligament",
      "display" : "Rupture of patella ligament",
      "definition" : "Rupture of patella ligament / Ruptur af patellasene"
    }]
  },
  {
    "code" : "thrombosis",
    "display" : "Thrombosis",
    "definition" : "Thrombosis / Trombose",
    "concept" : [{
      "code" : "dvt",
      "display" : "Dyb vene trombose",
      "definition" : "Dyb vene trombose"
    },
    {
      "code" : "abdominal",
      "display" : "Abdominal /hepatisk/milt trombose",
      "definition" : "Abdominal /hepatisk/milt trombose"
    }]
  },
  {
    "code" : "marrow_relapse",
    "display" : "Marrow relapse",
    "definition" : "Marrow relapse / Marv relaps"
  },
  {
    "code" : "rising_m_component",
    "display" : "Rising M-component",
    "definition" : "Rising M-component / Stigende M-komponent"
  },
  {
    "code" : "hypercalcemia",
    "display" : "Hypercalcemia",
    "definition" : "Hypercalcemia / Hypercalcæmi"
  },
  {
    "code" : "osteolytic_foci",
    "display" : "Progressive osteolytic foci",
    "definition" : "Progressive osteolytic foci / Progression af osteolytiske foci"
  },
  {
    "code" : "medullary_cross_sectional_syndrome",
    "display" : "Medullary cross-sectional syndrome",
    "definition" : "Medullary cross-sectional syndrome / Medullært tværsnitssyndrom"
  },
  {
    "code" : "extremedullery_myeloma",
    "display" : "Extremedullary Myeloma",
    "definition" : "Extremedullary Myeloma / Ekstramedullære Myelomer"
  },
  {
    "code" : "plasma_cell_leukemia",
    "display" : "Plasma cell leukemia",
    "definition" : "Plasma cell leukemia / Plasmacelle leukæmi"
  },
  {
    "code" : "uremia",
    "display" : "Uremia",
    "definition" : "Uremia / Uræmi / SNOMED-CT: 44730006",
    "concept" : [{
      "code" : "uremia_clinically",
      "display" : "Uremia (clinically significant)",
      "definition" : "Uremia (clinically significant) / Uræmi (klinisk betydende)"
    },
    {
      "code" : "uremia_dialysis",
      "display" : "Uremia (chronic dialysis requiring)",
      "definition" : "Uremia (chronic dialysis requiring) / Uræmi (kronisk dialysekrævende)"
    }]
  },
  {
    "code" : "amyloidosis",
    "display" : "Amyloidosis",
    "definition" : "Amyloidosis / Amyloidose / SNOMED-CT: 17602002"
  },
  {
    "code" : "neuropathy",
    "display" : "Neuropathy",
    "definition" : "Neuropathy / Neuropati / SNOMED-CT: 386033004"
  },
  {
    "code" : "hyperviscosity",
    "display" : "Hyperviscosity",
    "definition" : "Hyperviscosity / Hyperviskositet / SNOMED-CT: 64088006"
  },
  {
    "code" : "tci",
    "display" : "TCI",
    "definition" : "TCI"
  },
  {
    "code" : "bleeding",
    "display" : "Bleeding",
    "definition" : "Bleeding / Blødning"
  },
  {
    "code" : "apoplexia_cerebri",
    "display" : "Apopleksi cerebri",
    "definition" : "Apopleksi cerebri"
  },
  {
    "code" : "hematoma",
    "display" : "Surgery required hematoma",
    "definition" : "Surgery required hematoma / operationskrævende hæmatom"
  },
  {
    "code" : "lymph_leakage",
    "display" : "Lymph leakage over 2 days",
    "definition" : "Lymph leakage over 2 days / lymfesiven over 2 døgn (forlænger indlæggelsen)"
  },
  {
    "code" : "necrosis",
    "display" : "Surgery required necrosis",
    "definition" : "Surgery required necrosis / operationskrævende randnekrose"
  },
  {
    "code" : "lymphocele",
    "display" : "Surgery required lymphocele",
    "definition" : "Surgery required lymphocele / operationskrævende lymfocele"
  },
  {
    "code" : "superficial_subcutaneous_infection",
    "display" : "Superficial/subcutaneous infection",
    "definition" : "overfladisk / subcutan infektion (ved antibiotika eller operation)"
  },
  {
    "code" : "deep_prosthesis_infection",
    "display" : "Deep/prosthesis infection",
    "definition" : "Deep/prosthesis infection / dyb / protese infektion (ved antibiotika eller operation)"
  },
  {
    "code" : "segment_elevation_myocardial_infarction",
    "display" : "Type of heart attack",
    "definition" : "Type of heart attack that mainly affects your hearts lower chambers"
  },
  {
    "code" : "bundle_branch_block_myocardial_infarction",
    "display" : "Type of heart attack",
    "definition" : "--"
  },
  {
    "code" : "non_segment_elevation_myocardial_infarction",
    "display" : "Type of heart attack",
    "definition" : "--"
  },
  {
    "code" : "unstable_agina",
    "display" : "Heart failure?",
    "definition" : "--"
  },
  {
    "code" : "rulled_out_heart_attack",
    "display" : "No heart attack/failur",
    "definition" : "--"
  },
  {
    "code" : "anterior_segment_elevation_myocardial_infarction",
    "display" : "Postion",
    "definition" : "--"
  },
  {
    "code" : "non_anterior_segment_elevation_myocardial_infarction",
    "display" : "Position",
    "definition" : "--"
  },
  {
    "code" : "heart_failur_class_2",
    "display" : "Class 2 heartfailure",
    "definition" : "--"
  },
  {
    "code" : "heart_failur_class_3",
    "display" : "Class 3 heartfailure",
    "definition" : "--"
  },
  {
    "code" : "heart_failur_class_4",
    "display" : "Class 4 heartfailure",
    "definition" : "--"
  }]
}

```
