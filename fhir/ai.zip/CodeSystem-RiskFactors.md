# Risk factors - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Risk factors**

## CodeSystem: Risk factors 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/RiskFactors | *Version*:2.26.1 |
| Active as of 2022-07-11 | *Computable Name*:RiskFactors |

 
Risk factors 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Risikofaktorer DMPN](ValueSet-RisikofaktorerDMPN.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "RiskFactors",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/RiskFactors",
  "version" : "2.26.1",
  "name" : "RiskFactors",
  "title" : "Risk factors",
  "status" : "active",
  "date" : "2022-07-11T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Risk factors",
  "content" : "complete",
  "count" : 7,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "behavioural",
    "display" : "Behavioural",
    "definition" : "Behavioural"
  },
  {
    "code" : "physiological",
    "display" : "Physiological",
    "definition" : "Physiological",
    "concept" : [{
      "code" : "bmi",
      "display" : "Body mass index (BMI)",
      "definition" : "Body mass index (BMI)"
    },
    {
      "code" : "hypertension",
      "display" : "Hypertension",
      "definition" : "Hypertension"
    },
    {
      "code" : "hyperlipidemia",
      "display" : "Hyperlipidemia",
      "definition" : "Hyperlipidemia / Hyperlipidæmi"
    }]
  },
  {
    "code" : "environmental",
    "display" : "Environmental",
    "definition" : "Environmental"
  },
  {
    "code" : "genetic",
    "display" : "Genetic",
    "definition" : "Genetic"
  }]
}

```
