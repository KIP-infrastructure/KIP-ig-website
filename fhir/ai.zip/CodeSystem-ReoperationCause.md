# Cause of reoperation - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Cause of reoperation**

## CodeSystem: Cause of reoperation 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/ReoperationCause | *Version*:2.26.1 |
| Active as of 2022-12-06 | *Computable Name*:ReoperationCause |

 
Cause of reoperation 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Reoperation årsager (DKRR)](ValueSet-ReoperationAarsagDKRR.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "ReoperationCause",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/ReoperationCause",
  "version" : "2.26.1",
  "name" : "ReoperationCause",
  "title" : "Cause of reoperation",
  "status" : "active",
  "date" : "2022-12-06T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Cause of reoperation",
  "content" : "complete",
  "count" : 6,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "infection",
    "display" : "Infection",
    "definition" : "Infektion"
  },
  {
    "code" : "movement_restriction",
    "display" : "Movement restriction",
    "definition" : "Bevægelsesindskrænkning (artrofibrose)"
  },
  {
    "code" : "meniscus_damage",
    "display" : "Meniscus damage",
    "definition" : "Menisk skade"
  },
  {
    "code" : "cartilage_damage",
    "display" : "Cartilage damage",
    "definition" : "Brusk skade"
  },
  {
    "code" : "implant_removed",
    "display" : "Implant removed",
    "definition" : "Implantat fjernet"
  },
  {
    "code" : "cicatricial_tissue",
    "display" : "Cicatricial tissue",
    "definition" : "Arvæv/Cyklop dannelse"
  }]
}

```
