# Scandinavian Stroke Scale (SSS) - Eye motor skills - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Scandinavian Stroke Scale (SSS) - Eye motor skills**

## CodeSystem: Scandinavian Stroke Scale (SSS) - Eye motor skills 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/SSSEyeMotorSkills | *Version*:2.26.1 |
| Active as of 2022-06-23 | *Computable Name*:SSSEyeMotorSkills |

 
Scandinavian Stroke Scale (SSS) - Eye motor skills: Øjendeviation er ligeledes et dårligt prognostisk tegn. 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Scandinavian Stroke Scale - Øjenmotorik](ValueSet-SSSOejenmotorik.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "SSSEyeMotorSkills",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/SSSEyeMotorSkills",
  "version" : "2.26.1",
  "name" : "SSSEyeMotorSkills",
  "title" : "Scandinavian Stroke Scale (SSS) - Eye motor skills",
  "status" : "active",
  "date" : "2022-06-23T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Scandinavian Stroke Scale (SSS) - Eye motor skills: Øjendeviation er ligeledes et dårligt prognostisk tegn.",
  "content" : "complete",
  "count" : 3,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "4",
    "display" : "4",
    "definition" : "Parallelle, frie øjenbevægelser. Der må godt foreligge isolerede øjenmuskelpareser på den ene side."
  },
  {
    "code" : "2",
    "display" : "2",
    "definition" : "Konjugeret blikparese: Pt. kan ikke dreje øjnene samtidigt til den ene side."
  },
  {
    "code" : "0",
    "display" : "0",
    "definition" : "Blikdeviation: Pt.s øjne er tvangsmæssigt drejet til den ene side."
  }]
}

```
