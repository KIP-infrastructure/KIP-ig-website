# ASA klassifikation I-VI Kort - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ASA klassifikation I-VI Kort**

## ValueSet: ASA klassifikation I-VI Kort 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/ASAIVIkort | *Version*:2.26.1 |
| Active as of 2022-10-19 | *Computable Name*:ASAIVIkort |

 
ASA klassifikation I-VI i kort version 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "ASAIVIkort",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/ASAIVIkort",
  "version" : "2.26.1",
  "name" : "ASAIVIkort",
  "title" : "ASA klassifikation I-VI Kort",
  "status" : "active",
  "date" : "2022-10-19T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "ASA klassifikation I-VI i kort version",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/ASAClassification",
      "concept" : [{
        "code" : "asai",
        "display" : "ASA I"
      },
      {
        "code" : "asaii",
        "display" : "ASA II"
      },
      {
        "code" : "asaiii",
        "display" : "ASA III"
      },
      {
        "code" : "asaiv",
        "display" : "ASA IV"
      },
      {
        "code" : "asav",
        "display" : "ASA V"
      },
      {
        "code" : "asavi",
        "display" : "ASA VI"
      }]
    }]
  }
}

```
