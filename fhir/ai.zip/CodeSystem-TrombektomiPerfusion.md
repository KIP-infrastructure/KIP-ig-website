# Trombektomi-Perfusion (Danstroke) - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Trombektomi-Perfusion (Danstroke)**

## CodeSystem: Trombektomi-Perfusion (Danstroke) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/TrombektomiPerfusion | *Version*:2.26.1 |
| Active as of 2026-06-29 | *Computable Name*:TrombektomiPerfusionCS |

 
Perfusion opnået under trombektomi 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Trombektomi-Perfusion (Danstroke)](ValueSet-TrombektomiPerfusion.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "TrombektomiPerfusion",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/TrombektomiPerfusion",
  "version" : "2.26.1",
  "name" : "TrombektomiPerfusionCS",
  "title" : "Trombektomi-Perfusion (Danstroke)",
  "status" : "active",
  "date" : "2026-06-29T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Perfusion opnået under trombektomi",
  "content" : "complete",
  "count" : 4,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "med_reperfusion",
    "display" : "Hel/delvis reperfusion",
    "definition" : "Trombektomi med efterfølgende helt eller delvist opnået reperfusion"
  },
  {
    "code" : "uden_reperfusion",
    "display" : "Uden efterflg. reperfusion",
    "definition" : "Trombektomi uden efterfølgende reperfusion / procedure opgivet",
    "property" : [{
      "code" : "comment",
      "valueString" : "Modified"
    },
    {
      "code" : "effectiveDate",
      "valueDateTime" : "2026-06-29T00:00:00+02:00"
    },
    {
      "code" : "status",
      "valueCode" : "active"
    },
    {
      "code" : "inactive",
      "valueBoolean" : false
    }]
  },
  {
    "code" : "spontan_reperfusion",
    "display" : "Spontan reperfusion",
    "definition" : "Spontan reperfusion"
  },
  {
    "code" : "hypoperfusion",
    "display" : "Hypoperfusion uden trombektomi",
    "definition" : "Stenosebetinget hypoperfusion uden trombektomi",
    "property" : [{
      "code" : "comment",
      "valueString" : "Modified"
    },
    {
      "code" : "effectiveDate",
      "valueDateTime" : "2026-06-29T00:00:00+02:00"
    },
    {
      "code" : "status",
      "valueCode" : "active"
    },
    {
      "code" : "inactive",
      "valueBoolean" : false
    }]
  }]
}

```
