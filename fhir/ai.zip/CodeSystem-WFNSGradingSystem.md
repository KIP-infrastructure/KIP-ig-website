# WFNS grading system - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **WFNS grading system**

## CodeSystem: WFNS grading system 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/WFNSGradingSystem | *Version*:2.26.1 |
| Active as of 2022-06-28 | *Computable Name*:WFNSGradingSystem |

 
World Federation of Neurosurgical Societies (WFNS) grading system; Link: https://radiopaedia.org/articles/wfns-grading-system 

 This Code system is referenced in the content logical definition of the following value sets: 

* [WFSN grad](ValueSet-WFNSGradering.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "WFNSGradingSystem",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/WFNSGradingSystem",
  "version" : "2.26.1",
  "name" : "WFNSGradingSystem",
  "title" : "WFNS grading system",
  "status" : "active",
  "date" : "2022-06-28T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "World Federation of Neurosurgical Societies (WFNS) grading system; Link: https://radiopaedia.org/articles/wfns-grading-system",
  "content" : "complete",
  "count" : 5,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "grade1",
    "display" : "GCS 15",
    "definition" : "GCS 15, no motor deficit"
  },
  {
    "code" : "grade2",
    "display" : "GCS 13-14",
    "definition" : "GCS 13-14 without deficit"
  },
  {
    "code" : "grade3",
    "display" : "GCS 13-14",
    "definition" : "GCS 13-14 with focal neurological deficit"
  },
  {
    "code" : "grade4",
    "display" : "GCS 7-12",
    "definition" : "GCS 7-12, with or without deficit"
  },
  {
    "code" : "grade5",
    "display" : "GCS <7",
    "definition" : "GCS <7 , with or without deficit"
  }]
}

```
