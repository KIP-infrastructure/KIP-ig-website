# Housing type - KIP Infrastructure v2.26.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Housing type**

## CodeSystem: Housing type 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/HousingType | *Version*:2.26.0 |
| Active as of 2022-06-21 | *Computable Name*:HousingType |

 
Housing type 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Boligforhold (RETSPSYK)](ValueSet-BoligforholdRETSPSYK.md)
* [Boligform [DAP]](ValueSet-BoligformDAP.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "HousingType",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/HousingType",
  "version" : "2.26.0",
  "name" : "HousingType",
  "title" : "Housing type",
  "status" : "active",
  "date" : "2022-06-21T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Housing type",
  "content" : "complete",
  "count" : 7,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "private",
    "display" : "Private",
    "definition" : "Private / Privat"
  },
  {
    "code" : "house/apartment",
    "display" : "Hus/lejlighed",
    "definition" : "Hus/lejlighed (privat bolig)"
  },
  {
    "code" : "nursinghome",
    "display" : "Plejebolig",
    "definition" : "Plejebolig"
  },
  {
    "code" : "own_residence",
    "display" : "Own residence",
    "definition" : "Own residence / Egen bolig"
  },
  {
    "code" : "institution",
    "display" : "Institution",
    "definition" : "Institution"
  },
  {
    "code" : "homeless",
    "display" : "Homeless",
    "definition" : "Homeless / Hjemløs"
  },
  {
    "code" : "other",
    "display" : "Andet",
    "definition" : "Andet"
  }]
}

```
