# Assessment type - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Assessment type**

## CodeSystem: Assessment type 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/AssessmentType | *Version*:2.26.1 |
| Active as of 2025-05-09 | *Computable Name*:AssessmentType |

 
Assessment type 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Udredning (DANDEM)](ValueSet-UdredningDANDEM.md)
* [Udredning (DANDEM) 2025](ValueSet-UdredningDANDEM2025.md)
* [Udredning - Klinisk/genetisk](ValueSet-UdredningKliniskGenetisk.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "AssessmentType",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/AssessmentType",
  "version" : "2.26.1",
  "name" : "AssessmentType",
  "title" : "Assessment type",
  "status" : "active",
  "date" : "2025-05-09T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Assessment type",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 8,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "clinical",
    "display" : "Clinical",
    "definition" : "Clinical / Klinisk / SNOMED-CT: 58147004"
  },
  {
    "code" : "genetic_counseling",
    "display" : "Genetic counseling",
    "definition" : "Genetic counseling / Genetisk rådgivning / SNOMED-CT: 79841006"
  },
  {
    "code" : "primary_dementia_assessment",
    "display" : "Primary dementia assessment",
    "definition" : "Primary dementia assessment / Primær demensudredning"
  },
  {
    "code" : "second_opinion",
    "display" : "Second opinion",
    "definition" : "Second opinion"
  },
  {
    "code" : "referred_again_behavioral_problems",
    "display" : "Referred again beacause of behavioral problems",
    "definition" : "Referred again beacause of behavioral problems / Genhenvist pga. adfærdsforstyrrelser"
  },
  {
    "code" : "referred_again_dementia_treatment",
    "display" : "Referred again beacause of dementia treatment",
    "definition" : "Referred again beacause of dementia treatment / Genhenvist pga. demensbehandling"
  },
  {
    "code" : "revisited_primary_assessment",
    "display" : "Revisited for primary assessment",
    "definition" : "Revisited for primary assessment / Omvisiteret til primær udredning"
  },
  {
    "code" : "no_wish_for_assessment",
    "display" : "Patient interrupts investigation before diagnostic interview",
    "definition" : "Patient interrupts investigation before diagnostic interview / Patient afbryder udredning før diagnosesamtale"
  }]
}

```
