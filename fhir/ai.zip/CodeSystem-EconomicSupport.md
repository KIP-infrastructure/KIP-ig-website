# Economic support - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Economic support**

## CodeSystem: Economic support 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/EconomicSupport | *Version*:2.26.1 |
| Active as of 2022-09-30 | *Computable Name*:EconomicSupport |

 
Economic support 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Forsørgelsesgrundlag (RETSPSYK)](ValueSet-ForsoergelsesgrundlagRETSPSYK.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "EconomicSupport",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/EconomicSupport",
  "version" : "2.26.1",
  "name" : "EconomicSupport",
  "title" : "Economic support",
  "status" : "active",
  "date" : "2022-09-30T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Economic support",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 4,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "salary",
    "display" : "Salary",
    "definition" : "Salary / Lønindkomst"
  },
  {
    "code" : "education_support",
    "display" : "Education support",
    "definition" : "Education support / Uddannelsesstøtte"
  },
  {
    "code" : "cash_assistance",
    "display" : "Cash assistance",
    "definition" : "Cash assistance / Kontanthjælp"
  },
  {
    "code" : "pension",
    "display" : "Pension",
    "definition" : "Pension"
  }]
}

```
