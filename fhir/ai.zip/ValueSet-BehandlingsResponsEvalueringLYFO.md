# Responsevaluering på behandling (LYFO) - KIP Infrastructure v2.19.4

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Responsevaluering på behandling (LYFO)**

## ValueSet: Responsevaluering på behandling (LYFO) (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/BehandlingsResponsEvalueringLYFO | *Version*:2.19.4 |
| Active as of 2022-07-18 | *Computable Name*:BehandlingsResponsEvalueringLYFO |

 
Responsevaluering på behandling (LYFO) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BehandlingsResponsEvalueringLYFO",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/BehandlingsResponsEvalueringLYFO",
  "version" : "2.19.4",
  "name" : "BehandlingsResponsEvalueringLYFO",
  "title" : "Responsevaluering på behandling (LYFO)",
  "status" : "active",
  "experimental" : true,
  "date" : "2022-07-18T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Responsevaluering på behandling (LYFO)",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/TreatmentResponseEvaluation",
      "concept" : [{
        "code" : "complete_remission_metabolic_structurally",
        "display" : "CR (metabolisk og skrukturelt CR, bedømt med PET/CT)"
      },
      {
        "code" : "complete_remission_metabolic",
        "display" : "CR (metabolisk CR, men med strukturel restsygdom, bedømt med PET/CT)"
      },
      {
        "code" : "complete_remission",
        "display" : "CR (bedømt med CT og/eller klinisk)"
      },
      {
        "code" : "uncertain_complete_remission",
        "display" : "Cru"
      },
      {
        "code" : "partial_remission",
        "display" : "PR"
      },
      {
        "code" : "stable_disease",
        "display" : "SD/NC"
      },
      {
        "code" : "progressive_disease",
        "display" : "PD"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/GenericValues",
      "concept" : [{
        "code" : "not_performed",
        "display" : "Ej evalueret"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/Complications",
      "concept" : [{
        "code" : "mors",
        "display" : "Mors (før evaluering)"
      }]
    }]
  }
}

```
