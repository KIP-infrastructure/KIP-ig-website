# Performance Status score (ECOG/WHO/Zubrod) - KIP Infrastructure v2.26.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Performance Status score (ECOG/WHO/Zubrod)**

## CodeSystem: Performance Status score (ECOG/WHO/Zubrod) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/PerformanceStatusScore | *Version*:2.26.1 |
| Active as of 2022-05-31 | *Computable Name*:PerformanceStatusScore |

 
Score udviklet til performance for cancerpatienter. Kaldes både ECOG, WHO eller Zubrod. Link: https://ecog-acrin.org/resources/ecog-performance-status/ 

 This Code system is referenced in the content logical definition of the following value sets: 

* [ECOG Performance Status Scale](ValueSet-ECOG.md)
* [ECOG Performance Status Skala til HÆMA specialerne](ValueSet-ECOGHAEMA.md)
* [WHO Performance status grad 1-4](ValueSet-WHOPerformanceStatus04.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "PerformanceStatusScore",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/PerformanceStatusScore",
  "version" : "2.26.1",
  "name" : "PerformanceStatusScore",
  "title" : "Performance Status score (ECOG/WHO/Zubrod)",
  "status" : "active",
  "date" : "2022-05-31T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Score udviklet til performance for cancerpatienter. Kaldes både ECOG, WHO eller Zubrod. Link: https://ecog-acrin.org/resources/ecog-performance-status/",
  "content" : "complete",
  "count" : 6,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "grade_0",
    "display" : "0",
    "definition" : "Fully active, able to carry on all pre-disease performance without restriction"
  },
  {
    "code" : "grade_1",
    "display" : "1",
    "definition" : "Restricted in physically strenuous activity but ambulatory and able to carry out work of a light or sedentary nature, e.g., light house work, office work"
  },
  {
    "code" : "grade_2",
    "display" : "2",
    "definition" : "Ambulatory and capable of all selfcare but unable to carry out any work activities; up and about more than 50% of waking hours"
  },
  {
    "code" : "grade_3",
    "display" : "3",
    "definition" : "Capable of only limited selfcare; confined to bed or chair more than 50% of waking hours"
  },
  {
    "code" : "grade_4",
    "display" : "4",
    "definition" : "Completely disabled; cannot carry on any selfcare; totally confined to bed or chair"
  },
  {
    "code" : "grade_5",
    "display" : "5",
    "definition" : "Dead"
  }]
}

```
