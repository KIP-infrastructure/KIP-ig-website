# Killip sværhedsgrad - KIP Infrastructure v2.14.1

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Killip sværhedsgrad**

## ValueSet: Killip sværhedsgrad (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/HeartFailure | *Version*:2.14.1 |
| Active as of 2022-06-07 | *Computable Name*:HeartFailure |

 
Killip sværhedsgrad af hjertestop 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "HeartFailure",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/HeartFailure",
  "version" : "2.14.1",
  "name" : "HeartFailure",
  "title" : "Killip sværhedsgrad",
  "status" : "active",
  "experimental" : true,
  "date" : "2022-06-07T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [
    {
      "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
      "telecom" : [
        {
          "system" : "url",
          "value" : "https://trifork.com"
        },
        {
          "system" : "email",
          "value" : "rbk@trifork.com"
        }
      ]
    }
  ],
  "description" : "Killip sværhedsgrad af hjertestop",
  "compose" : {
    "include" : [
      {
        "system" : "https://kip.rkkp.dk/fhir/CodeSystem/Complications",
        "concept" : [
          {
            "code" : "heart_failur_class_2",
            "display" : "Killip klasse 2 (Væskeraslen ved respiration/halsvenestase)"
          },
          {
            "code" : "heart_failur_class_3",
            "display" : "Killip klasse 3 (Lungeødem)"
          },
          {
            "code" : "heart_failur_class_4",
            "display" : "Killip klasse 4 (Kardiogent shock)"
          }
        ]
      }
    ]
  }
}

```
