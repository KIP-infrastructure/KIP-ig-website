# Korsbånd ikke bevaret - KIP Infrastructure v2.23.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Korsbånd ikke bevaret**

## CodeSystem: Korsbånd ikke bevaret 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/KorsbaandEjBevaret | *Version*:2.23.5 |
| Active as of 2023-12-18 | *Computable Name*:KorsbaandEjBevaretCS |

 
Korsbånd ikke bevaret efter operation 

 This Code system is referenced in the content logical definition of the following value sets: 

* [KorsbaandEjBevaret](ValueSet-KorsbaandEjBevaret.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "KorsbaandEjBevaret",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/KorsbaandEjBevaret",
  "version" : "2.23.5",
  "name" : "KorsbaandEjBevaretCS",
  "title" : "Korsbånd ikke bevaret",
  "status" : "active",
  "date" : "2023-12-18T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Korsbånd ikke bevaret efter operation",
  "content" : "complete",
  "count" : 3,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "ofret",
    "display" : "Ofret ved kirurgi",
    "definition" : "Ofret ved kirurgi"
  },
  {
    "code" : "fravaerende",
    "display" : "Fraværende",
    "definition" : "Fraværende"
  },
  {
    "code" : "beskadiget",
    "display" : "Beskadiget",
    "definition" : "Beskadiget"
  }]
}

```
