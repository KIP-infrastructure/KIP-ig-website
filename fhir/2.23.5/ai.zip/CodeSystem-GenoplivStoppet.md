# Genoplivning indstillet - årsag - KIP Infrastructure v2.23.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Genoplivning indstillet - årsag**

## CodeSystem: Genoplivning indstillet - årsag 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/GenoplivStoppet | *Version*:2.23.5 |
| Active as of 2022-06-29 | *Computable Name*:GenoplivStoppetCS |

 
Årsager til indstilling af genoplivningsforsøg 

 This Code system is referenced in the content logical definition of the following value sets: 

* [GenoplivStoppet](ValueSet-GenoplivStoppet.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "GenoplivStoppet",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/GenoplivStoppet",
  "version" : "2.23.5",
  "name" : "GenoplivStoppetCS",
  "title" : "Genoplivning indstillet - årsag",
  "status" : "active",
  "date" : "2022-06-29T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Årsager til indstilling af genoplivningsforsøg",
  "content" : "complete",
  "count" : 3,
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "spontan_kreds",
    "display" : "Spontant kredsløb",
    "definition" : "Spontant kredsløb"
  },
  {
    "code" : "doed",
    "display" : "Død",
    "definition" : "Død"
  },
  {
    "code" : "kunstig_kreds",
    "display" : "Kunstig kredsløb (f.eks. ECMO, CPS, m.fl.)",
    "definition" : "Kunstig kredsløb (f.eks. ECMO, CPS, m.fl.)"
  }]
}

```
