# Dansk national biobank - KIP Infrastructure v2.23.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Dansk national biobank**

## ValueSet: Dansk national biobank (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/BiobankSamples | *Version*:2.23.5 |
| Active as of 2022-06-29 | *Computable Name*:BiobankSamples |

 
Dansk national biobank - Samples og matrialer 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BiobankSamples",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/BiobankSamples",
  "version" : "2.23.5",
  "name" : "BiobankSamples",
  "title" : "Dansk national biobank",
  "status" : "active",
  "experimental" : true,
  "date" : "2022-06-29T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Dansk national biobank - Samples og matrialer",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/BiobankSamples",
      "concept" : [{
        "code" : "serum/plasma",
        "display" : "Serum / Plasma"
      },
      {
        "code" : "vital_frozen",
        "display" : "Mononukleære marvceller (Vitalfrosne)"
      },
      {
        "code" : "not_vital_frozen",
        "display" : "Mononukleære marvceller (Ikke Vitalfrosne)"
      },
      {
        "code" : "isolated",
        "display" : "Isolerede myelomceller"
      },
      {
        "code" : "marrow_cells",
        "display" : "Andre marvceller"
      },
      {
        "code" : "rna",
        "display" : "RNA"
      },
      {
        "code" : "dna",
        "display" : "DNA"
      },
      {
        "code" : "marrow_plasma",
        "display" : "Marvplasma"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/GenericValues",
      "concept" : [{
        "code" : "other",
        "display" : "Andet"
      }]
    }]
  }
}

```
