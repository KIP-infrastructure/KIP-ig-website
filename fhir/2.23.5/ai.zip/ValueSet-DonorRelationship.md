# Relationen til doner - KIP Infrastructure v2.23.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Relationen til doner**

## ValueSet: Relationen til doner (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/DonorRelationship | *Version*:2.23.5 |
| Active as of 2022-07-13 | *Computable Name*:DonorRelationship |

 
Familie relation til donor 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "DonorRelationship",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/DonorRelationship",
  "version" : "2.23.5",
  "name" : "DonorRelationship",
  "title" : "Relationen til doner",
  "status" : "active",
  "experimental" : true,
  "date" : "2022-07-13T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Familie relation til donor",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/SNOMEDCT",
      "concept" : [{
        "code" : "303071001",
        "display" : "Familiedonor"
      },
      {
        "code" : "11286003",
        "display" : "Tvilling"
      },
      {
        "code" : "394863008",
        "display" : "Ubeslægtet"
      }]
    },
    {
      "system" : "http://terminology.hl7.org/CodeSystem/v2-0532",
      "version" : "3.0.0",
      "concept" : [{
        "code" : "UNK",
        "display" : "Uvist"
      }]
    }]
  }
}

```
