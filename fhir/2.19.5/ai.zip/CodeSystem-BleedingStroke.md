# Bleeding - Stroke - KIP Infrastructure v2.19.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bleeding - Stroke**

## CodeSystem: Bleeding - Stroke 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/BleedingStroke | *Version*:2.19.5 |
| Active as of 2022-09-01 | *Computable Name*:BleedingStroke |

 
Bleeding - Stroke 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Anden blødning (DAP)](ValueSet-AndenBloedningDAP.md)
* [Lokal blødning (DAP)](ValueSet-LokalBloedningDAP.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BleedingStroke",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/BleedingStroke",
  "version" : "2.19.5",
  "name" : "BleedingStroke",
  "title" : "Bleeding - Stroke",
  "status" : "active",
  "date" : "2022-09-01T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Bleeding - Stroke",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 6,
  "concept" : [{
    "code" : "hi_1",
    "display" : "HI 1",
    "definition" : "HI 1"
  },
  {
    "code" : "hi_2",
    "display" : "HI 2",
    "definition" : "HI 2"
  },
  {
    "code" : "ph_1",
    "display" : "PH 1",
    "definition" : "PH 1"
  },
  {
    "code" : "ph_2",
    "display" : "PH 2",
    "definition" : "PH 2"
  },
  {
    "code" : "phr_1",
    "display" : "PHr 1",
    "definition" : "PHr 1"
  },
  {
    "code" : "phr_2",
    "display" : "PHr 2",
    "definition" : "PHr 2"
  }]
}

```
