# Bulking materiale - Urogynækologi (DUGA) - KIP Infrastructure v2.19.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Bulking materiale - Urogynækologi (DUGA)**

## CodeSystem: Bulking materiale - Urogynækologi (DUGA) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/BulkingMaterialeDUGA | *Version*:2.19.5 |
| Active as of 2024-02-14 | *Computable Name*:BulkingMaterialeDUGA |

 
Bulking materiale - Urogynækologi (DUGA) 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BulkingMateriale (DUGA)](ValueSet-BulkingMaterialeDUGA.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BulkingMaterialeDUGA",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/BulkingMaterialeDUGA",
  "version" : "2.19.5",
  "name" : "BulkingMaterialeDUGA",
  "title" : "Bulking materiale - Urogynækologi (DUGA)",
  "status" : "active",
  "date" : "2024-02-14T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Bulking materiale - Urogynækologi (DUGA)",
  "content" : "complete",
  "count" : 3,
  "concept" : [{
    "code" : "Bulkamid",
    "display" : "Bulkamid",
    "definition" : "Bulkamid"
  },
  {
    "code" : "Deflux",
    "display" : "Deflux",
    "definition" : "Deflux"
  },
  {
    "code" : "Macroplastik",
    "display" : "Macroplastik",
    "definition" : "Macroplastik"
  }]
}

```
