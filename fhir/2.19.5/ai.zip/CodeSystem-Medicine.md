# Medicine - KIP Infrastructure v2.19.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Medicine**

## CodeSystem: Medicine 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/Medicine | *Version*:2.19.5 |
| Active as of 2022-10-06 | *Computable Name*:Medicine |

 
Medicine 

 This Code system is referenced in the content logical definition of the following value sets: 

* [Medicin præparat (DSR)](ValueSet-MedicinPraeparatDSR.md)
* [Trombolysepræparater](ValueSet-Trombolysepraeparater.md)
* [Varighed PostOP trombolyseprofylakse (DKR)](ValueSet-VarighedPostOPTrombDKR.md)
* [Varighed PostOP trombolyseprofylakse (DKR)1](ValueSet-VarighedPostOPTrombDKR1.md)
* [Varighed PostOP trombolyseprofylakse (DKR)2](ValueSet-VarighedPostOPTrombDKR2.md)
* [Varighed PostOP trombolyseprofylakse (DKR)3](ValueSet-VarighedPostOPTrombDKR3.md)
* [Varighed PostOP trombolyseprofylakse (DKR)NOAK](ValueSet-VarighedPostOPTrombDKRNOAK.md)
* [Varighed PostOP trombolyseprofylakse (DKR) VitK_anta](ValueSet-VarighedPostOPTrombDKRVitKanta.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "Medicine",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/Medicine",
  "version" : "2.19.5",
  "name" : "Medicine",
  "title" : "Medicine",
  "status" : "active",
  "date" : "2022-10-06T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Medicine",
  "caseSensitive" : false,
  "content" : "complete",
  "count" : 10,
  "concept" : [{
    "code" : "beh-vitamin_k",
    "display" : "Vitamin-K-antagonist",
    "definition" : "Behandling med vitamin-K-antagonist"
  },
  {
    "code" : "noak_a",
    "display" : "NOAK halv dosis",
    "definition" : "NOAK halv dosis"
  },
  {
    "code" : "noak_b",
    "display" : "NOAK fuld dosis",
    "definition" : "NOAK fuld dosis"
  },
  {
    "code" : "noak_c",
    "display" : "NOAK fuld dosis postop",
    "definition" : "NOAK fuld dosis postop"
  },
  {
    "code" : "antibiotics",
    "display" : "Antibiotics",
    "definition" : "Antibiotics / Antibiotika"
  },
  {
    "code" : "penicillin",
    "display" : "Penicillin",
    "definition" : "Penicillin"
  },
  {
    "code" : "penicillinase_stabile",
    "display" : "Penicillinasestabilt penicilin",
    "definition" : "Penicillinasestabilt penicilin"
  },
  {
    "code" : "cephalosporin",
    "display" : "Cefalosporin",
    "definition" : "Cefalosporin"
  },
  {
    "code" : "alteplase",
    "display" : "Actilyse (alteplase)",
    "definition" : "Actilyse (alteplase)"
  },
  {
    "code" : "tenecteplase",
    "display" : "Metalyse (tenecteplase)",
    "definition" : "Metalyse (tenecteplase)"
  }]
}

```
