# Behandlinger foretaget i forbindelse med MDS (MDS) - KIP Infrastructure v2.19.5

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Behandlinger foretaget i forbindelse med MDS (MDS)**

## ValueSet: Behandlinger foretaget i forbindelse med MDS (MDS) (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ValueSet/BehandlingMDS | *Version*:2.19.5 |
| Active as of 2022-07-19 | *Computable Name*:BehandlingMDS |

 
Behandlinger foretaget i forbindelse med MDS (MDS) 

 **References** 

This value set is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)

### Logical Definition (CLD)

 

### Expansion

-------

 Explanation of the columns that may appear on this page: 

| | |
| :--- | :--- |
| Level | A few code lists that FHIR defines are hierarchical - each code is assigned a level. In this scheme, some codes are under other codes, and imply that the code they are under also applies |
| System | The source of the definition of the code (when the value set draws in codes defined elsewhere) |
| Code | The code (used as the code in the resource instance) |
| Display | The display (used in the*display*element of a[Coding](http://hl7.org/fhir/R4/datatypes.html#Coding)). If there is no display, implementers should not simply display the code, but map the concept into their application |
| Definition | An explanation of the meaning of the concept |
| Comments | Additional notes about how to use the code |



## Resource Content

```json
{
  "resourceType" : "ValueSet",
  "id" : "BehandlingMDS",
  "url" : "https://kip.rkkp.dk/fhir/ValueSet/BehandlingMDS",
  "version" : "2.19.5",
  "name" : "BehandlingMDS",
  "title" : "Behandlinger foretaget i forbindelse med MDS (MDS)",
  "status" : "active",
  "experimental" : true,
  "date" : "2022-07-19T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Behandlinger foretaget i forbindelse med MDS (MDS)",
  "compose" : {
    "include" : [{
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/SKS",
      "concept" : [{
        "code" : "BOQA",
        "display" : "Transfusion"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/ATC",
      "concept" : [{
        "code" : "B03XA01",
        "display" : "Erythropoietin"
      },
      {
        "code" : "L01XX05",
        "display" : "Hydroxurea"
      },
      {
        "code" : "L04A",
        "display" : "Immunosupressiv behandling"
      },
      {
        "code" : "L04AX04",
        "display" : "Lenalidomid"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/TreatmentUnspecified",
      "concept" : [{
        "code" : "g_csf",
        "display" : "G-CSF"
      },
      {
        "code" : "iron_chelated",
        "display" : "Jernkelerende behandling"
      },
      {
        "code" : "demethylating",
        "display" : "Demethylerende behandling"
      },
      {
        "code" : "chemotherapi_aml",
        "display" : "AML lignende kemoterapi"
      }]
    },
    {
      "system" : "https://kip.rkkp.dk/fhir/CodeSystem/GenericValues",
      "concept" : [{
        "code" : "other",
        "display" : "Anden behandling"
      }]
    }]
  }
}

```
