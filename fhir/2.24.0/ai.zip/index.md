# Home - KIP Infrastructure v2.24.0

* [**Table of Contents**](toc.md)
* **Home**

## Home

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/ImplementationGuide/dk.kip.rkkp.fhir.ig.core | *Version*:2.24.0 |
| Active as of 2026-08-05 | *Computable Name*:KIPInfrastructure |

### Introduction

This implementation guide is provided to support the use of FHIR®© in the context of Sundhedsvæsenets Kvalitetsinstitut.

