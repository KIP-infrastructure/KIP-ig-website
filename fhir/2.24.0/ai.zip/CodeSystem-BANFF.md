# Banff Classifikation - KIP Infrastructure v2.24.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **Banff Classifikation**

## CodeSystem: Banff Classifikation 

| | |
| :--- | :--- |
| *Official URL*:https://kip.rkkp.dk/fhir/CodeSystem/BANFF | *Version*:2.24.0 |
| Active as of 2024-10-01 | *Computable Name*:BANFF |

 
Banff Classifikation 

 This Code system is referenced in the content logical definition of the following value sets: 

* [BanffClassifikation](ValueSet-BanffClassifikation.md)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "BANFF",
  "url" : "https://kip.rkkp.dk/fhir/CodeSystem/BANFF",
  "version" : "2.24.0",
  "name" : "BANFF",
  "title" : "Banff Classifikation",
  "status" : "active",
  "date" : "2024-10-01T00:00:00+02:00",
  "publisher" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
  "contact" : [{
    "name" : "Sundhedsvæsenets Kvalitetsinstitut with Trifork Digital Health A/S",
    "telecom" : [{
      "system" : "url",
      "value" : "https://trifork.com"
    },
    {
      "system" : "email",
      "value" : "rbk@trifork.com"
    }]
  }],
  "description" : "Banff Classifikation",
  "content" : "fragment",
  "property" : [{
    "code" : "comment",
    "uri" : "http://hl7.org/fhir/concept-properties#comment",
    "description" : "A string that provides additional detail pertinent to the use or understanding of the concept",
    "type" : "string"
  },
  {
    "code" : "effectiveDate",
    "uri" : "http://hl7.org/fhir/concept-properties#effectiveDate",
    "description" : "The date at which the concept status was last changed",
    "type" : "dateTime"
  },
  {
    "code" : "status",
    "uri" : "http://hl7.org/fhir/concept-properties#status",
    "description" : "A code that indicates the status of the concept. Typical values are active, experimental, deprecated, and retired",
    "type" : "code"
  },
  {
    "code" : "inactive",
    "uri" : "http://hl7.org/fhir/concept-properties#inactive",
    "description" : "True if the concept is not considered active - e.g. not a valid concept any more. Property type is boolean, default value is false. Note that the status property may also be used to indicate that a concept is inactive",
    "type" : "boolean"
  }],
  "concept" : [{
    "code" : "Borderline",
    "display" : "Borderline",
    "definition" : "Borderline"
  },
  {
    "code" : "1A",
    "display" : "1A",
    "definition" : "1A"
  },
  {
    "code" : "1B",
    "display" : "1B",
    "definition" : "1B"
  },
  {
    "code" : "2A",
    "display" : "2A",
    "definition" : "2A"
  },
  {
    "code" : "2B",
    "display" : "2B",
    "definition" : "2B"
  },
  {
    "code" : "3",
    "display" : "3",
    "definition" : "3"
  },
  {
    "code" : "InsufBiopsi",
    "display" : "Insufficient biopsi",
    "definition" : "Insufficient biopsi"
  },
  {
    "code" : "AntistofMedi",
    "display" : "Antistof-medieret",
    "definition" : "Antistof-medieret"
  }]
}

```
